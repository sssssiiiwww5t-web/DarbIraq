درب العراق — حزمة 3 أوامر لـ Termux

تنبيه: بناء Android كامل من Termux قد يفشل بسبب متطلبات Android SDK/AGP على بيئة الهاتف. لا تعتبر APK جاهزاً حتى ينجح الأمر الثاني فعلياً. التنزيلات كبيرة (Gradle وAndroid SDK إن أضيفت)، لذلك لا تشغلها إذا كانت الباقة محدودة.

طريقة الاستخدام:
1) فك الضغط عن هذه الحزمة إلى مجلد Downloads.
2) افتح Termux وشغّل:
   bash ~/storage/downloads/DarbIraq_3Commands/01_setup.sh
   bash ~/storage/downloads/DarbIraq_3Commands/02_build.sh
   bash ~/storage/downloads/DarbIraq_3Commands/03_install.sh

إذا مجلد الحزمة مختلف، عدّل المسار حسب مكان فك الضغط. يحتاج إذن التخزين أول مرة: termux-setup-storage

هذه حزمة مصدر أولية؛ خرائط ومسارات تجريبية عبر الإنترنت، لا يوجد ازدحام مباشر أو ملاحة صوتية كاملة.
