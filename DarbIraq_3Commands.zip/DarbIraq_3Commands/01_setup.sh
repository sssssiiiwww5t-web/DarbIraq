#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "== Darb Iraq: one-command project setup =="
pkg update -y
pkg install -y git wget unzip openjdk-17
mkdir -p "$HOME/DarbIraq"
cd "$HOME/DarbIraq"
if [ ! -f settings.gradle.kts ]; then
  cat > settings.gradle.kts <<'EOF'
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = "DarbIraq"
include(":app")
EOF
  cat > build.gradle.kts <<'EOF'
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
EOF
  cat > gradle.properties <<'EOF'
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
EOF
  mkdir -p app/src/main/java/iq/darbiraq/app app/src/main/assets .github/workflows
  cat > app/build.gradle.kts <<'EOF'
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "iq.darbiraq.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "iq.darbiraq.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
EOF
  cat > app/src/main/AndroidManifest.xml <<'EOF'
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="درب العراق" android:usesCleartextTraffic="false" android:allowBackup="false" android:supportsRtl="true">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter>
        </activity>
    </application>
</manifest>
EOF
  cat > app/src/main/java/iq/darbiraq/app/MainActivity.kt <<'EOF'
package iq.darbiraq.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity: Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val w=WebView(this)
  w.settings.javaScriptEnabled=true
  w.settings.domStorageEnabled=true
  w.webViewClient=WebViewClient()
  setContentView(w)
  w.loadUrl("file:///android_asset/index.html")
 }
}
EOF
  cat > app/src/main/assets/index.html <<'EOF'
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>درب العراق</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"><style>
*{box-sizing:border-box}body{margin:0;background:#07111d;color:#fff;font-family:system-ui,sans-serif}header{padding:18px;background:#102033;display:flex;gap:12px;align-items:center}.logo{background:#29d391;color:#062117;padding:12px;border-radius:13px;font-size:22px;font-weight:bold}h2{margin:0;font-size:21px}small{color:#a7b8c9}.search{display:flex;gap:8px;padding:12px;background:#0a1724}input{min-width:0;flex:1;padding:13px;border-radius:12px;border:1px solid #2b4054;background:#17283a;color:white;font-size:15px}button{border:0;border-radius:12px;padding:12px;background:#29d391;color:#062117;font-weight:bold}nav{display:flex;gap:8px;padding:0 12px 12px;background:#0a1724}nav button{flex:1;background:#203548;color:white}#map{height:55vh;min-height:290px;background:#dce8e6}.status{margin:12px;padding:13px;background:#101f2f;border-radius:12px;color:#b7c6d5;line-height:1.7;font-size:13px}.status b{color:white}.foot{text-align:center;padding:8px;color:#8194a7;font-size:10px}</style></head><body>
<header><div class="logo">د</div><div><h2>درب العراق</h2><small>طريقك أوضح • إصدار تجريبي 0.1</small></div></header>
<div class="search"><input id="q" placeholder="وين تريد تروح؟"><button onclick="searchPlace()">بحث</button></div><nav><button onclick="locate()">📍 موقعي</button><button onclick="route()">🧭 احسب الطريق</button></nav><div id="map"></div><div class="status" id="s"><b>هلا بيك بدرب العراق</b><br>ابحث عن وجهتك أو حدد موقعك. يلزم اتصال إنترنت لتحميل الخريطة.</div><div class="foot">© OpenStreetMap • بيانات تجريبية من خدمات عامة</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script><script>
const s=document.getElementById('s'),say=t=>s.innerHTML=t;const map=L.map('map').setView([33.3152,44.3661],6);L.control.zoom({position:'bottomright'}).addTo(map);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);let me=null,to=null,ml=null,dl=null,rl=null;
function locate(){if(!navigator.geolocation){say('تحديد الموقع غير مدعوم.');return}say('جاري تحديد موقعك…');navigator.geolocation.getCurrentPosition(p=>{me=[p.coords.latitude,p.coords.longitude];map.setView(me,15);if(ml)map.removeLayer(ml);ml=L.marker(me).addTo(map).bindPopup('موقعك').openPopup();say('<b>تم تحديد موقعك</b><br>ابحث عن الوجهة ثم احسب الطريق.')},()=>say('تعذر تحديد الموقع. فعّل إذن الموقع وGPS.'))}
async function searchPlace(){let q=document.getElementById('q').value.trim();if(!q){say('اكتب اسم مكان أولاً.');return}say('جاري البحث…');try{let r=await fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=iq&q='+encodeURIComponent(q));let d=await r.json();if(!d.length)throw Error('ما لكينا المكان');to=[+d[0].lat,+d[0].lon];if(dl)map.removeLayer(dl);dl=L.marker(to).addTo(map).bindPopup(d[0].display_name);map.setView(to,13);say('<b>تم العثور على الوجهة</b><br>'+d[0].display_name)}catch(e){say('فشل البحث: '+e.message)}}
async function route(){if(!me||!to){say('حدد موقعك وابحث عن وجهتك أولاً.');return}say('جاري حساب المسار…');try{let r=await fetch(`https://router.project-osrm.org/route/v1/driving/${me[1]},${me[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`),d=await r.json();if(d.code!=='Ok')throw Error('لا يوجد مسار');if(rl)map.removeLayer(rl);rl=L.geoJSON(d.routes[0].geometry,{style:{color:'#0aa875',weight:6}}).addTo(map);map.fitBounds(rl.getBounds(),{padding:[20,20]});say(`<b>المسار التجريبي جاهز</b><br>المسافة: ${(d.routes[0].distance/1000).toFixed(1)} كم<br>الوقت التقديري: ${Math.round(d.routes[0].duration/60)} دقيقة<br>لا توجد بيانات ازدحام مباشر.`)}catch(e){say('تعذر حساب الطريق: '+e.message)}}
</script></body></html>
EOF
fi
echo
echo "تم تجهيز ملفات المصدر في: $HOME/DarbIraq"
echo "الخطوة التالية: شغّل الأمر الثاني لبناء APK."
