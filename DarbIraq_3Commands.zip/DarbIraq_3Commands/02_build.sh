#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg install -y wget unzip openjdk-17
cd "$HOME/DarbIraq"
if [ ! -x "$HOME/gradle-8.9/bin/gradle" ]; then
  wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O "$HOME/gradle-8.9-bin.zip"
  unzip -q "$HOME/gradle-8.9-bin.zip" -d "$HOME"
fi
export JAVA_HOME="$PREFIX/opt/openjdk"
export PATH="$HOME/gradle-8.9/bin:$JAVA_HOME/bin:$PATH"
gradle --no-daemon assembleDebug
mkdir -p "$HOME/storage/downloads"
cp app/build/outputs/apk/debug/app-debug.apk "$HOME/storage/downloads/DarbIraq-debug.apk"
echo "APK: $HOME/storage/downloads/DarbIraq-debug.apk"
