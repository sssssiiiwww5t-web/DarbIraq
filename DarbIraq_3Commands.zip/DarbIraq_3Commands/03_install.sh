#!/data/data/com.termux/files/usr/bin/bash
set -e
APK="$HOME/storage/downloads/DarbIraq-debug.apk"
if [ -f "$APK" ]; then
  ls -lh "$APK"
  termux-open "$APK"
else
  echo "APK not found yet. Run 02_build.sh and wait for a successful build."
fi
